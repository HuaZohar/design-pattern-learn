package com.java.stimulateduck.flybehavior;

public interface FlyBehavior {
	void fly();
}
