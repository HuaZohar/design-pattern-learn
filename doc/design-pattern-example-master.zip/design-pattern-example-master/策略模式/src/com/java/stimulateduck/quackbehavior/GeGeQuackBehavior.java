package com.java.stimulateduck.quackbehavior;


public	class GeGeQuackBehavior implements QuackBehavior
{

	@Override
	public void quack() {
		// TODO Auto-generated method stub
		System.out.println("__GeGe__");
	}
	
}
