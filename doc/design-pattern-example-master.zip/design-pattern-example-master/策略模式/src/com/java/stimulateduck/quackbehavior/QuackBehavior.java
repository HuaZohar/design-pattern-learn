package com.java.stimulateduck.quackbehavior;

public	interface QuackBehavior {
	void quack();
};