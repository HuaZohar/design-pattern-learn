package com.java.coffeebar.coffee;

public class LongBlack extends Coffee{
	
	public LongBlack()
	{
		super.setDescription("LongBlack");
		super.setPrice(6.0f);
	}

}

