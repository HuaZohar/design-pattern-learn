package com.java.flyweight.ms;

public class TreeFlyWeight {

	public TreeFlyWeight() {

	}

	public void display(int xCoord, int yCoord, int age) {
		// System.out.print("x");
	}

}
