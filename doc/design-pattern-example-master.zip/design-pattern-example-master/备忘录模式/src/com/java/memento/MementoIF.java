package com.java.memento;

/**
 * 备忘录模式，定义接口，不需要写方法，起到安全保护和统一存储的作用
 */
public interface MementoIF {

}
