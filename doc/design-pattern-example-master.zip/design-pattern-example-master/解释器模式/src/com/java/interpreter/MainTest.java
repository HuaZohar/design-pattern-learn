package com.java.interpreter;


/**
 * 解释器模式：定义一个语法, 定义一个解释器，该解释器处理该语法句子
 */
public class MainTest {

	public static void main(String[] args) {

		new Calculator();
	}

}
