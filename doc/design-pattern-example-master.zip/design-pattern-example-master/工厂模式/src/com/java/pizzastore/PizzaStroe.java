package com.java.pizzastore;



/**
 * OO模式，统一在订单类中进行分类生产，不同的条件创建不同的对象
 */
public class PizzaStroe {
	public static void main(String[] args) {
		
		OrderPizza mOrderPizza;
		mOrderPizza=new	OrderPizza();
		
	}

	

}
