package com.java.pizzastore.method;


/**
 * 工厂方法模式，利用继承的关系，给不同的工厂实现各自的生产方法
 */
public class PizzaStroe {
	public static void main(String[] args) {
		
		OrderPizza mOrderPizza;
		mOrderPizza=new	NYOrderPizza();
		
	}

	

}
