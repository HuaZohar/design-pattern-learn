package com.java.adaptermode.turkey;

/**
 * 火鸡对象实现的接口方法
 */
public interface Turkey {

	public void gobble();
	public void fly();

}
