package com.java.iteratormode;


/**
 * 面向对象模式
 */
public class MainTest {
	public static void main(String[] args) {
	
		Waitress mWaitress=new Waitress();
		
		mWaitress.printMenu();
	}
}
