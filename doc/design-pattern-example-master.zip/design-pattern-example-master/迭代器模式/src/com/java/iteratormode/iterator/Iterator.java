package com.java.iteratormode.iterator;

/**
 * 自定义迭代器接口
 */
public interface Iterator {
	
	public boolean hasNext();
	public Object next();
	

}
