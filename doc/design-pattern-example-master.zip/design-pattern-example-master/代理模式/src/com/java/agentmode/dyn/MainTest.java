package com.java.agentmode.dyn;


/**
 * 动态代理，保护代理
 */
public class MainTest {


	public static void main(String[] args) {
		
		MatchService mMatchService=new MatchService();
	}


}
